/* 
 * File:   main.cpp
 * Author: Esmeralda Loredo
 * Created on February 18, 2015, 9:56 AM
 *      Purpose: Our first Program! 
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std;// Standard namespace for the I/O stream 


// User Libraries
  
//Global Constants 

// Function Prototypes

//Execution begins here!

int main(int argc, char** argv) {
//Output Hello World
    cout<<"Hello World"<<endl;
    //Exit stage right!
    return 0;
}

